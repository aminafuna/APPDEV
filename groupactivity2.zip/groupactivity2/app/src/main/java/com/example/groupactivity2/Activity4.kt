package com.example.groupactivity2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Activity4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_4)

        val txtLastName: TextView = findViewById(R.id.txtLastName)
        val btnBack: Button = findViewById(R.id.btnBack)

        val lastName = intent.getStringExtra("LAST_NAME")
        txtLastName.text = lastName

        btnBack.setOnClickListener {
            finish() // Go back to MainActivity
        }
    }
}
