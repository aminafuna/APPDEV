package com.example.groupactivity2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnDeLosSantos: Button = findViewById(R.id.btnDeLosSantos)
        val btnFuna: Button = findViewById(R.id.btnFuna)
        val btnJimenez: Button = findViewById(R.id.btnJimenez)
        val btnSeguisa: Button = findViewById(R.id.btnSeguisa)

        val listener = View.OnClickListener { v ->
            val clickedButton = v as Button
            val lastName = clickedButton.text.toString()
            val intent = Intent(this, DisplayActivity::class.java).apply {
                putExtra("LAST_NAME", lastName)
            }
            startActivity(intent)
        }

        btnDeLosSantos.setOnClickListener(listener)
        btnFuna.setOnClickListener(listener)
        btnJimenez.setOnClickListener(listener)
        btnSeguisa.setOnClickListener(listener)
    }
}
