package com.example.weatherforecastapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class WeatherDetailActivity extends AppCompatActivity {

    private TextView textViewCityName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_detail);

        String cityName = getIntent().getStringExtra("CITY_NAME");

        textViewCityName = findViewById(R.id.textViewCityName);
        textViewCityName.setText("Weather for: " + cityName);

        WeatherSummaryFragment summaryFragment = new WeatherSummaryFragment();
        WeatherDetailFragment detailFragment = new WeatherDetailFragment();

        Bundle bundle = new Bundle();
        bundle.putString("CITY_NAME", cityName);
        summaryFragment.setArguments(bundle);
        detailFragment.setArguments(bundle);

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragmentContainerSummary, summaryFragment);
        transaction.replace(R.id.fragmentContainerDetail, detailFragment);
        transaction.commit();
    }
}
