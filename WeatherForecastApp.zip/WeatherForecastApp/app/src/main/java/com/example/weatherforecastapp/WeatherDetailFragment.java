package com.example.weatherforecastapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class WeatherDetailFragment extends Fragment {

    private TextView textViewWeatherDetails;

    public WeatherDetailFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_weather_detail, container, false);

        // Initialize UI elements
        textViewWeatherDetails = view.findViewById(R.id.textViewWeatherDetails);

        // Get arguments passed from WeatherDetailActivity
        Bundle bundle = getArguments();
        if (bundle != null) {
            String cityName = bundle.getString("CITY_NAME", "Unknown City");
            displayWeatherDetails(cityName);
        }

        return view;
    }

    private void displayWeatherDetails(String cityName) {
        // Dummy weather details (replace with actual API call if needed)
        String weatherInfo = "City: " + cityName + "\n" +
                "Temperature: 28°C\n" +
                "Humidity: 65%\n" +
                "Condition: Partly Cloudy";

        // Display weather details
        textViewWeatherDetails.setText(weatherInfo);
    }
}
