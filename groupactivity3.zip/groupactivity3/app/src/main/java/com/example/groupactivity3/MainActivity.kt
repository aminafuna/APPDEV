package com.example.groupactivity3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.example.groupactivity3.ui.theme.Groupactivity3Theme



class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { Groupactivity3Theme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController, startDestination = "home") {
        composable("home") { Show(navController) }
        composable("Amina") { AminaScreen(navController) }
        composable("Vea") { VeaScreen(navController) }
        composable("Missy") { MissyScreen(navController) }
        composable("Kreshea") { KresheaScreen(navController) }
    }
}

@Composable
fun Show(navController: NavHostController) {
    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {
        Text(text = "Date: March 14, 2025\n\n\n")

        Button(onClick = { navController.navigate("Amina" +
                "") }) {
            Text(text = "Amina")
        }
        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = { navController.navigate("Vea") }) {
            Text(text = "Vea")
        }
        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = { navController.navigate("Missy") }) {
            Text(text = "Missy")
        }

        Button(onClick = { navController.navigate("Kreshea") }) {
            Text(text = "Kreshea")
        }
    }
}

@Composable
fun AminaScreen(navController: NavHostController) {
    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {
        Text(text = "Jesmond Sardiniola Cute!")

        Button(onClick = { navController.navigate("home") }) {
            Text(text = "Back")
        }


    }
}

@Composable
fun SelwynScreen(navController: NavHostController) {
    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {
        Text(text = "Selwyn Jayme Pinakagwapo!!")

        Button(onClick = { navController.navigate("home") }) {
            Text(text = "Back")

        }



    }
}

@Composable
fun NavarraScreen(navController: NavHostController) {
    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {
        Text(text = "Norman Navarra Pogi!")

        Button(onClick = { navController.navigate("home") }) {
            Text(text = "Back")
        }


    }
}

@Preview
@Composable
fun PreviewShow() {
    Show(rememberNavController())
}
