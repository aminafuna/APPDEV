package com.example.funaact6;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText editTextFahrenheit;
    private TextView textViewCelsius, textViewError;
    private Button buttonConvert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextFahrenheit = findViewById(R.id.editTextFahrenheit);
        textViewCelsius = findViewById(R.id.textViewCelsius);
        textViewError = findViewById(R.id.textViewError);
        buttonConvert = findViewById(R.id.buttonConvert);

        buttonConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertTemperature();
            }
        });
    }

    private void convertTemperature() {
        String input = editTextFahrenheit.getText().toString().trim();

        if (input.isEmpty()) {
            textViewError.setText("Please enter a valid number.");
            textViewCelsius.setText("");
            return;
        }

        try {
            double fahrenheit = Double.parseDouble(input);
            double celsius = (fahrenheit - 32) * 5 / 9;
            textViewCelsius.setText(String.format("%.2f °C", celsius));
            textViewError.setText(""); // Clear error message on success
        } catch (NumberFormatException e) {
            textViewError.setText("Invalid input. Please enter a numeric value.");
            textViewCelsius.setText("");
        }
    }
}